"""
Obsidian 知识库服务

通过 WebDAV 或本地文件系统连接 Obsidian 仓库，自动生成 DEBUG 记录笔记。

模式：
- WebDAV 模式：设置 OBSIDIAN_WEBDAV_URL 后通过 WebDAV 协议访问远程仓库
- 本地模式（默认）：当 WebDAV 未配置时，直接读取本地文件系统上的仓库
"""

import json
import logging
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import unquote

import httpx

from app.config.database import get_connection
from app.middlewares.error_handler import AppError

logger = logging.getLogger(__name__)

# WebDAV 配置
DEFAULT_WEBDAV_URL = os.getenv("OBSIDIAN_WEBDAV_URL", "")
DEFAULT_WEBDAV_USER = os.getenv("OBSIDIAN_WEBDAV_USER", "")
DEFAULT_WEBDAV_PASS = os.getenv("OBSIDIAN_WEBDAV_PASS", "")
DEFAULT_VAULT_PATH = os.getenv("OBSIDIAN_VAULT_PATH", "/服务器维修笔记/AI分析记录/")
DEFAULT_RESOLVED_PATH = os.getenv("OBSIDIAN_RESOLVED_PATH", "/服务器维修笔记/已解决/")

# 本地文件系统配置
LOCAL_VAULT_PATH = os.getenv("OBSIDIAN_LOCAL_PATH", "/vault")


def _get_settings() -> dict:
    """从数据库获取 Obsidian 配置"""
    conn = get_connection()
    rows = conn.execute(
        "SELECT key, value FROM ai_settings WHERE key LIKE 'obsidian_%'"
    ).fetchall()
    config = {row["key"]: row["value"] for row in rows}

    return {
        "webdav_url": config.get("obsidian_webdav_url", DEFAULT_WEBDAV_URL),
        "webdav_user": config.get("obsidian_webdav_user", DEFAULT_WEBDAV_USER),
        "webdav_pass": config.get("obsidian_webdav_pass", DEFAULT_WEBDAV_PASS),
        "vault_path": config.get("obsidian_vault_path", DEFAULT_VAULT_PATH),
        "browse_paths": json.loads(config.get("obsidian_browse_paths", "[]")),
        "resolved_path": config.get("obsidian_resolved_path", ""),
        "auto_save": config.get("obsidian_auto_save", "false") == "true",
    }


def _is_within(path: Path, base: Path) -> bool:
    """判断 path 是否位于 base 目录内（含 base 自身），防止路径穿越。"""
    try:
        path.relative_to(base)
    except ValueError:
        return False
    return True


def _make_webdav_url(base_url: str, path: str) -> str:
    """构建 WebDAV URL"""
    base = base_url.rstrip("/")
    path = path.lstrip("/")
    return f"{base}/{path}"


def _webdav_auth(user: str, password: str) -> httpx.BasicAuth | None:
    """构建 WebDAV 认证"""
    if user:
        return httpx.BasicAuth(user, password)
    return None


async def _webdav_mkdir(url: str, auth: httpx.BasicAuth | None, path: str) -> None:
    """递归创建 WebDAV 目录"""
    parts = [p for p in path.split("/") if p]
    current = url.rstrip("/")

    for part in parts:
        current = f"{current}/{part}"
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.request("MKCOL", current, auth=auth)
                if resp.status_code not in (200, 201, 405):
                    logger.warning(f"MKCOL {current} failed: {resp.status_code}")
        except Exception as e:
            logger.warning(f"MKCOL {current} error: {e}")


async def _webdav_put(url: str, auth: httpx.BasicAuth | None, content: str) -> bool:
    """上传文件到 WebDAV"""
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.put(
                url,
                content=content.encode("utf-8"),
                headers={"Content-Type": "text/markdown; charset=utf-8"},
                auth=auth,
            )
            return resp.status_code in (200, 201, 204)
    except Exception as e:
        logger.error(f"WebDAV PUT failed: {e}")
        return False


async def _webdav_get(url: str, auth: httpx.BasicAuth | None) -> Optional[str]:
    """从 WebDAV 下载文件"""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(url, auth=auth)
            if resp.status_code == 200:
                return resp.text
            return None
    except Exception as e:
        logger.error(f"WebDAV GET failed: {e}")
        return None


async def _webdav_list(url: str, auth: httpx.BasicAuth | None) -> list[dict]:
    """列出 WebDAV 目录内容。

    失败时抛出 AppError（带可读消息），以便上层区分"连接/认证失败"与"目录为空"，
    不再静默返回 [] 导致前端误显示 "No notes"。
    """
    headers = {"Depth": "1"}
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.request("PROPFIND", url, headers=headers, auth=auth)

    if resp.status_code == 401:
        raise AppError("Obsidian WebDAV 认证失败，请在设置中检查用户名/密码")
    if resp.status_code == 404:
        raise AppError("Obsidian WebDAV 仓库路径不存在，请检查路径配置")
    if resp.status_code != 207:
        raise AppError(f"Obsidian WebDAV 返回异常状态 {resp.status_code}")

    items = []
    text = resp.text

    # 解析 XML 响应 - 兼容 DAV 命名空间的各种前缀（d: D: s: 等）以及无前缀（默认命名空间）。
    # 此前只认 d:/D: 前缀，NAS 返回无前缀标签时解析为空 -> 侧边栏误显示 "No notes"。
    ns = r"(?:[a-zA-Z]+:)?"
    href_pattern = re.compile(rf"<{ns}href>([^<]+)</{ns}href>", re.IGNORECASE)
    collection_pattern = re.compile(rf"<{ns}collection\b[^>]*>", re.IGNORECASE)
    response_pattern = re.compile(rf"<{ns}response>(.*?)</{ns}response>", re.DOTALL | re.IGNORECASE)

    responses = response_pattern.findall(text)

    for resp_text in responses:
        href_match = href_pattern.search(resp_text)
        if not href_match:
            continue

        href = href_match.group(1)
        name = unquote(href.rstrip("/").split("/")[-1])

        is_collection = bool(collection_pattern.search(resp_text))

        items.append({
            "name": name,
            "href": href,
            "is_collection": is_collection,
        })

    return items


def _sanitize_filename(title: str) -> str:
    """生成安全的文件名"""
    safe = re.sub(r'[<>:"/\\|?*]', '', title)
    if len(safe) > 50:
        safe = safe[:50]
    return safe.strip()


COMPILE_CASE_PROMPT = """你是产线故障案例整理助手。把下面这段产线测试诊断对话和日志，整理成一个"已解决故障案例"。

严格按以下格式输出，每段以 ===段名=== 开头，段与段之间用空行分隔，不要任何额外说明或前后缀：

===原始日志===
<从日志里摘出关键错误行/关键字段，保留原样，不要编造>

===故障原因===
<故障部件 + 根因判定，1-3 句>

===AI建议===
<AI 给出的排查/维修方向建议，用编号列表（1. 2. 3.），每条一个独立方向，不要 == 标记>

===DEBUG诊断===
<用到的 Linux 诊断命令，每条一行，不要 == 标记、不要反引号>

===定位过程===
<排查定位的步骤，简明分步>

===维修操作===
<若对话里明确提到实际修复动作（如用户反馈"换件后通过""重插拔好了""重跑 PASS"等），则如实填入；否则留空，由工程师补填>

对话：
{conversation}

日志：
{log}
"""


def _parse_case_sections(text: str) -> dict:
    """解析 AI 输出的 ===段名=== 结构为 6 段 dict。"""
    mapping = {
        "原始日志": "log",
        "故障原因": "cause",
        "AI建议": "suggestion",
        "DEBUG诊断": "debug",
        "定位过程": "process",
        "维修操作": "repair",
    }
    result = {k: "" for k in mapping.values()}
    parts = re.split(r"={2,}\s*([^=\n]+?)\s*={2,}", text)
    i = 1
    while i + 1 < len(parts):
        key = mapping.get(parts[i].strip())
        if key:
            result[key] = parts[i + 1].strip()
        i += 2
    return result


def _wrap_resolved_note(title: str, model: str, now: str, user: str, body: str) -> str:
    """用 frontmatter 包裹前端组装好的正文，落盘到已解决案例。"""
    model_line = model or "未分类"
    return f"""---
model: {model_line}
title: {title}
date: {now}
user: {user}
type: resolved
tags:
  - resolved
  - {model_line}
---

# [{model_line}] {title}

{body}
"""


def generate_note_content(
    title: str,
    model: str,
    log_summary: str,
    log_snippet: str,
    analysis: str,
    repair_notes: str = "",
    user: str = "admin",
    body: str = "",
) -> str:
    """生成已解决的笔记内容。
    - body 非空：直接用前端组装好的正文（6 段结构），只包 frontmatter；
    - 否则：按 analysis 关键词切分（旧逻辑）。
    """
    now = datetime.utcnow().isoformat() + "Z"
    if body:
        return _wrap_resolved_note(title, model, now, user, body)
    sections = parse_analysis(analysis)

    # 提取日志关键字段（前 10 行非空行）
    key_lines = [l for l in log_snippet.strip().split("\n") if l.strip()][:10]
    key_fields = "\n".join(key_lines) if key_lines else log_snippet[:500]

    repair_content = repair_notes.strip() if repair_notes else sections.get('solution', '（待补充）')

    content = f"""---
model: {model}
title: {title}
date: {now}
user: {user}
type: resolved
tags:
  - resolved
  - {model}
---

# [{model}] {title}

## 📋 测试报错日志
```log
{key_fields}
```

## 🎯 故障部件定位
{sections.get('cause', '（待补充）')}

## 🔬 定位过程
{sections.get('method', '（待补充）')}

## 🔧 维修操作
{repair_content}

## ⚠️ 批量风险评估
{sections.get('improvement', '（个案处理，暂不升级）')}
"""
    return content


def parse_analysis(analysis: str) -> dict:
    """解析 AI 分析结果为结构化内容（产线测试流程版本）"""
    sections = {
        "summary": "",
        "cause": "",
        "method": "",
        "solution": "",
        "conclusion": "",
        "improvement": "",
    }

    lines = analysis.split("\n")
    current_section = None
    current_content = []

    for line in lines:
        lower = line.lower().strip()

        if any(kw in lower for kw in ["测试报错", "报错日志", "日志概要", "日志摘要", "概要", "测试现象"]):
            if current_section and current_content:
                sections[current_section] = "\n".join(current_content)
            current_section = "summary"
            current_content = []
        elif any(kw in lower for kw in ["故障部件", "部件定位", "故障定位", "故障原因", "原因分析", "根因", "可能原因"]):
            if current_section and current_content:
                sections[current_section] = "\n".join(current_content)
            current_section = "cause"
            current_content = []
        elif any(kw in lower for kw in ["定位过程", "排查方法", "排查过程", "诊断方法", "方法", "分析步骤"]):
            if current_section and current_content:
                sections[current_section] = "\n".join(current_content)
            current_section = "method"
            current_content = []
        elif any(kw in lower for kw in ["维修操作", "维修方案", "维修建议", "解决方案", "解决方法", "处理方案", "更换方案"]):
            if current_section and current_content:
                sections[current_section] = "\n".join(current_content)
            current_section = "solution"
            current_content = []
        elif any(kw in lower for kw in ["批量风险", "风险评估", "质量事件", "预防措施", "改善建议", "后续改善", "后续", "改善", "改进"]):
            if current_section and current_content:
                sections[current_section] = "\n".join(current_content)
            current_section = "improvement"
            current_content = []
        elif any(kw in lower for kw in ["总结", "结论"]):
            if current_section and current_content:
                sections[current_section] = "\n".join(current_content)
            current_section = "conclusion"
            current_content = []
        elif current_section:
            current_content.append(line)

    if current_section and current_content:
        sections[current_section] = "\n".join(current_content)

    if not any(sections.values()):
        sections["summary"] = analysis

    return sections


class ObsidianService:
    """Obsidian 知识库服务 - 支持 WebDAV 和本地文件系统双模式"""

    # ============================================================
    # 模式判断
    # ============================================================

    def _is_webdav_configured(self) -> bool:
        """判断是否配置了 WebDAV"""
        config = _get_settings()
        return bool(config["webdav_url"])

    def _get_local_vault_dir(self, resolved: bool = False) -> Path:
        """获取本地仓库目录"""
        config = _get_settings()
        if resolved:
            vault_path = DEFAULT_RESOLVED_PATH.strip("/")
        else:
            vault_path = config.get("vault_path", DEFAULT_VAULT_PATH).strip("/")
        local_base = Path(LOCAL_VAULT_PATH)
        return local_base / vault_path

    def _get_target_path(self, resolved: bool = False) -> str:
        """获取 WebDAV 保存目标路径"""
        config = _get_settings()
        if resolved:
            return DEFAULT_RESOLVED_PATH.strip("/")
        return config.get("vault_path", DEFAULT_VAULT_PATH).strip("/")

    # ============================================================
    # 本地文件系统操作
    # ============================================================

    def _local_get_file_tree(self, path: str = "") -> list[dict]:
        """从本地文件系统获取文件树"""
        vault_dir = self._get_local_vault_dir()
        vault_root = vault_dir.resolve()

        # 安全校验：拒绝穿越
        if path and ".." in Path(path).parts:
            logger.warning(f"拒绝越界路径访问: {path}")
            return []

        target_dir = (vault_dir / path.strip("/")) if path else vault_dir
        try:
            target_dir = target_dir.resolve()
        except OSError:
            return []
        if not _is_within(target_dir, vault_root):
            logger.warning(f"拒绝越界目录访问: {path} -> {target_dir}")
            return []

        if not target_dir.exists() or not target_dir.is_dir():
            logger.warning(f"Local vault directory not found: {target_dir}")
            return []

        return self._local_list_dir(target_dir, vault_dir)

    def _local_list_dir(self, current_dir: Path, vault_base: Path) -> list[dict]:
        """递归列目录"""
        result = []

        try:
            entries = sorted(current_dir.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
        except PermissionError:
            return []

        for entry in entries:
            # 跳过隐藏文件和特定目录
            if entry.name.startswith("."):
                continue
            if entry.name in (".obsidian", ".trash", ".git"):
                continue

            try:
                rel_path = str(entry.relative_to(vault_base)).replace("\\", "/")
            except ValueError:
                rel_path = entry.name

            if entry.is_dir():
                children = self._local_list_dir(entry, vault_base)
                result.append({
                    "name": entry.name,
                    "path": rel_path,
                    "type": "folder",
                    "children": children,
                })
            elif entry.suffix.lower() == ".md":
                result.append({
                    "name": entry.name,
                    "path": rel_path,
                    "type": "file",
                })

        return result

    def _local_get_file_content(self, path: str) -> Optional[str]:
        """从本地文件系统读取文件内容"""
        vault_dir = self._get_local_vault_dir()
        vault_root = vault_dir.resolve()

        clean_path = path
        # 安全校验：绝对路径与 .. 段一律禁止，防止读取 vault 外文件
        if clean_path.startswith("/") or ".." in Path(clean_path).parts:
            logger.warning(f"拒绝越界路径访问: {path}")
            return None

        # 只允许在 vault 目录内查找
        candidates = [vault_dir / clean_path]

        for file_path in candidates:
            try:
                resolved = file_path.resolve()
                if not _is_within(resolved, vault_root):
                    logger.warning(f"拒绝越界文件访问: {path} -> {resolved}")
                    continue
                if resolved.exists() and resolved.is_file():
                    return resolved.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError, PermissionError):
                continue

        logger.warning(f"Local file not found: {path}")
        return None

    def _local_list_notes(self) -> list[dict]:
        """从本地文件系统获取笔记列表"""
        vault_dir = self._get_local_vault_dir()

        if not vault_dir.exists():
            return []

        notes = []
        for entry in vault_dir.rglob("*.md"):
            if entry.name == "index.md":
                continue
            # 跳过隐藏目录
            if any(part.startswith(".") for part in entry.parts):
                continue
            if ".obsidian" in entry.parts or ".trash" in entry.parts:
                continue

            name = entry.name
            parts = name.replace(".md", "").split("_", 1)
            date = parts[0] if len(parts) > 0 else ""
            title = parts[1] if len(parts) > 1 else name

            try:
                rel_path = str(entry.relative_to(vault_dir)).replace("\\", "/")
            except ValueError:
                rel_path = name

            notes.append({
                "filename": name,
                "path": rel_path,
                "date": date,
                "title": title,
            })

        notes.sort(key=lambda x: x["date"], reverse=True)
        return notes

    def _local_save_note(
        self, title: str, save_path: str, log_summary: str, log_snippet: str,
        analysis: str, repair_notes: str = "", user: str = "admin", resolved: bool = False,
    ) -> dict:
        """保存笔记到本地文件系统"""
        vault_dir = self._get_local_vault_dir(resolved)
        vault_dir.mkdir(parents=True, exist_ok=True)

        date_str = datetime.utcnow().strftime("%Y-%m-%d")
        safe_title = _sanitize_filename(title)
        filename = f"{date_str}_{safe_title}.md"

        content = generate_note_content(
            title=title, model=save_path,
            log_summary=log_summary,
            log_snippet=log_snippet,
            analysis=analysis,
            repair_notes=repair_notes,
            user=user,
        )

        file_path = vault_dir / filename
        try:
            file_path.write_text(content, encoding="utf-8")
            logger.info(f"Note saved locally: {file_path}")
            return {"success": True, "filename": filename, "message": "笔记保存成功"}
        except Exception as e:
            logger.error(f"Failed to save note locally: {e}")
            return {"success": False, "filename": "", "message": f"保存失败: {e}"}

    def _local_search_notes(self, query: str) -> list[dict]:
        """本地全文搜索笔记"""
        vault_dir = self._get_local_vault_dir()
        results = []

        if not vault_dir.exists():
            return []

        md_files = list(vault_dir.rglob("*.md"))
        for file_path in md_files[:50]:  # 限制搜索数量
            if file_path.name == "index.md":
                continue
            if any(part.startswith(".") for part in file_path.parts):
                continue
            if ".obsidian" in file_path.parts or ".trash" in file_path.parts:
                continue

            try:
                content = file_path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue

            title = file_path.stem
            if query.lower() in title.lower() or query.lower() in content.lower():
                snippet = self._extract_snippet(content, query)
                try:
                    rel_path = str(file_path.relative_to(vault_dir)).replace("\\", "/")
                except ValueError:
                    rel_path = file_path.name
                results.append({
                    "filename": file_path.name,
                    "path": rel_path,
                    "title": title,
                    "snippet": snippet,
                })

        return results

    # ============================================================
    # 公共 API
    # ============================================================

    def get_settings(self) -> dict:
        """获取知识库配置"""
        config = _get_settings()
        config["local_vault_path"] = LOCAL_VAULT_PATH
        config["is_local_mode"] = not bool(config["webdav_url"])
        return config

    def update_settings(self, settings: dict) -> None:
        """更新知识库配置"""
        conn = get_connection()
        for key, value in settings.items():
            db_key = f"obsidian_{key}"
            # browse_paths 需要 JSON 序列化
            val = json.dumps(value) if key == "browse_paths" and isinstance(value, list) else str(value)
            conn.execute(
                "INSERT OR REPLACE INTO ai_settings (key, value) VALUES (?, ?)",
                (db_key, val),
            )
        conn.commit()

    async def save_note(
        self,
        title: str,
        save_path: str = "",
        log_summary: str = "",
        log_snippet: str = "",
        analysis: str = "",
        repair_notes: str = "",
        user: str = "admin",
        resolved: bool = False,
        body: str = "",
    ) -> dict:
        """保存笔记。resolved=True -> 写入本地。body 非空则直接落盘正文，repair_notes 由用户填写"""
        if resolved:
            return self._save_resolved_local(title, save_path, log_summary, log_snippet, analysis, repair_notes, user, body)
        if self._is_webdav_configured():
            return await self._save_note_webdav(title, save_path, log_summary, log_snippet, analysis, repair_notes, user, False)
        else:
            return self._local_save_note(title, save_path, log_summary, log_snippet, analysis, repair_notes, user, False)

    async def compile_case_draft(self, session_id: str) -> dict:
        """编译整段对话+日志为结构化案例草稿（6 段）。AI 不可用则回退启发式。"""
        from app.services.log_service import log_service
        from app.services.message_service import message_service

        messages = message_service.get_messages(session_id)
        log_summary = log_service.get_logs_summary_for_session(session_id)

        convo = "\n\n".join(
            f"[{m.role.value}]\n{m.content}" for m in messages
        ) or "(无对话内容)"

        try:
            from app.services.ai_service import ai_service
            prompt = COMPILE_CASE_PROMPT.format(
                conversation=convo[:12000], log=log_summary or "(无日志)"
            )
            result = await ai_service.chat(
                [
                    {"role": "system", "content": "你是产线故障案例整理助手，只按指定格式输出。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,
            )
            sections = _parse_case_sections(result)
            logger.info("案例草稿 AI 编译完成")
        except Exception as e:
            logger.warning(f"AI 编译草稿失败，回退启发式: {e}")
            sections = self._heuristic_case_sections(messages, log_summary)

        # 维修操作：保留 AI 从对话里提取的实际修复动作（若有）；对话里没提到则留空，
        # 由前端防呆面板引导工程师勾选/补填。不再强制清空。
        sections["success"] = True
        return sections

    def _heuristic_case_sections(self, messages: list, log_summary: str) -> dict:
        """AI 不可用时的启发式切分：把所有 AI 回复拼起来按 parse_analysis 切。"""
        ai_text = "\n\n".join(m.content for m in messages if m.role.value == "assistant")
        sections = parse_analysis(ai_text)
        return {
            "log": log_summary or sections.get("summary", ""),
            "cause": sections.get("cause", ""),
            "suggestion": sections.get("solution", ""),
            "debug": "",
            "process": sections.get("method", ""),
            "repair": "",
        }

    def _save_resolved_local(
        self, title: str, save_path: str, log_summary: str, log_snippet: str,
        analysis: str, repair_notes: str = "", user: str = "admin", body: str = "",
    ) -> dict:
        """已解决 → /resolved/{resolved_path}/{save_path}/{标题}.md"""
        config = _get_settings()
        resolved_base = config.get("resolved_path", "").strip().strip("/")
        base = Path("/resolved") / resolved_base if resolved_base else Path("/resolved")
        clean_path = save_path.strip().strip("/")
        target_dir = base / _sanitize_filename(clean_path) if clean_path else base
        target_dir.mkdir(parents=True, exist_ok=True)

        date_str = datetime.utcnow().strftime("%Y-%m-%d")
        safe_title = _sanitize_filename(title)
        filename = f"{date_str}_{safe_title}.md"

        content = generate_note_content(
            title=title, model=clean_path, log_summary=log_summary, log_snippet=log_snippet,
            analysis=analysis, repair_notes=repair_notes, user=user, body=body,
        )

        file_path = target_dir / filename
        rel = str(file_path.relative_to(base))
        try:
            file_path.write_text(content, encoding="utf-8")
            logger.info(f"Resolved note saved: {file_path}")
            return {"success": True, "filename": rel, "message": f"已保存到 已解决/{clean_path}"}
        except Exception as e:
            logger.error(f"Failed to save resolved note: {e}")
            return {"success": False, "filename": "", "message": f"保存失败: {e}"}

    async def _save_note_webdav(
        self, title: str, save_path: str, log_summary: str, log_snippet: str,
        analysis: str, repair_notes: str = "", user: str = "admin", resolved: bool = False,
    ) -> dict:
        """通过 WebDAV 保存笔记"""
        config = _get_settings()

        if not config["webdav_url"]:
            return {"success": False, "filename": "", "message": "未配置 WebDAV 地址"}

        auth = _webdav_auth(config["webdav_user"], config["webdav_pass"])
        base_url = config["webdav_url"].rstrip("/")
        vault_path = self._get_target_path(resolved)

        await _webdav_mkdir(base_url, auth, vault_path)

        date_str = datetime.utcnow().strftime("%Y-%m-%d")
        safe_title = _sanitize_filename(title)
        filename = f"{date_str}_{safe_title}.md"

        content = generate_note_content(
            title=title, model=save_path,
            log_summary=log_summary,
            log_snippet=log_snippet,
            analysis=analysis,
            repair_notes=repair_notes,
            user=user,
        )

        file_url = _make_webdav_url(base_url, f"{vault_path}/{filename}")
        success = await _webdav_put(file_url, auth, content)

        if success:
            await self._update_index(base_url, auth, vault_path, filename, title)
            return {"success": True, "filename": filename, "message": "笔记保存成功"}
        else:
            return {"success": False, "filename": "", "message": "笔记保存失败"}

    async def _update_index(self, base_url, auth, vault_path, filename, title):
        """更新 index.md 索引表"""
        index_url = _make_webdav_url(base_url, f"{vault_path}/index.md")
        date_str = datetime.utcnow().strftime("%Y-%m-%d")

        existing = await _webdav_get(index_url, auth)

        if existing:
            if "| 日期 |" in existing:
                new_row = f"| {date_str} | {title} | [[{filename.replace('.md', '')}]] |"
                lines = existing.rstrip().split("\n")
                lines.append(new_row)
                content = "\n".join(lines) + "\n"
            else:
                content = existing.rstrip() + "\n\n"
                content += "| 日期 | 标题 | 链接 |\n|------|------|------|\n"
                content += f"| {date_str} | {title} | [[{filename.replace('.md', '')}]] |\n"
        else:
            content = f"""---
title: DEBUG 记录索引
updated: {datetime.utcnow().isoformat()}Z
---

# DEBUG 记录索引

| 日期 | 标题 | 链接 |
|------|------|------|
| {date_str} | {title} | [[{filename.replace('.md', '')}]] |
"""

        await _webdav_put(index_url, auth, content)

    async def list_notes(self) -> list[dict]:
        """获取笔记列表（WebDAV 优先，本地回退）"""
        if self._is_webdav_configured():
            return await self._list_notes_webdav()
        else:
            return self._local_list_notes()

    async def _list_notes_webdav(self) -> list[dict]:
        """通过 WebDAV 获取笔记列表"""
        config = _get_settings()

        auth = _webdav_auth(config["webdav_user"], config["webdav_pass"])
        base_url = config["webdav_url"].rstrip("/")
        vault_path = config["vault_path"].strip("/")

        dir_url = _make_webdav_url(base_url, vault_path)
        try:
            items = await _webdav_list(dir_url, auth)
        except AppError:
            raise
        except Exception as e:
            logger.error(f"列出笔记失败 (WebDAV 网络异常): {e}")
            raise AppError("Obsidian 知识库连接失败，请检查 WebDAV 服务是否可达")

        notes = []
        for item in items:
            name = item["name"]
            if item.get("is_collection") or name == "index.md":
                continue
            parts = name.replace(".md", "").split("_", 1)
            date = parts[0] if len(parts) > 0 else ""
            title = parts[1] if len(parts) > 1 else name
            notes.append({"filename": name, "date": date, "title": title})

        notes.sort(key=lambda x: x["date"], reverse=True)
        return notes

    async def get_note_content(self, filename: str) -> Optional[str]:
        """获取笔记内容（WebDAV 优先，本地回退）"""
        if self._is_webdav_configured():
            return await self._get_note_content_webdav(filename)
        else:
            return self._local_get_file_content(filename)

    async def _get_note_content_webdav(self, filename: str) -> Optional[str]:
        """通过 WebDAV 获取笔记内容"""
        config = _get_settings()

        auth = _webdav_auth(config["webdav_user"], config["webdav_pass"])
        base_url = config["webdav_url"].rstrip("/")
        vault_path = config["vault_path"].strip("/")

        file_url = _make_webdav_url(base_url, f"{vault_path}/{filename}")
        return await _webdav_get(file_url, auth)

    async def get_file_tree(self, path: str = "") -> list[dict]:
        """获取文件树结构（WebDAV 优先，本地回退）"""
        if self._is_webdav_configured():
            return await self._get_file_tree_webdav(path)
        else:
            return self._local_get_file_tree(path)

    async def _get_file_tree_webdav(self, path: str = "") -> list[dict]:
        """通过 WebDAV 获取文件树（从 Vault 根目录开始浏览）"""
        # 安全校验：禁止穿越到 vault 之外
        if path and any(part == ".." for part in path.split("/")):
            logger.warning(f"拒绝越界 WebDAV 路径: {path}")
            return []
        config = _get_settings()
        auth = _webdav_auth(config["webdav_user"], config["webdav_pass"])
        base_url = config["webdav_url"].rstrip("/")

        from urllib.parse import urlparse
        p = urlparse(base_url)
        self._webdav_root = f"{p.scheme}://{p.netloc}"
        self._base_path = unquote(p.path.strip("/"))  # e.g. "Obsidian Vault"

        dir_url = f"{self._webdav_root}/{self._base_path}/{path.strip('/')}" if path.strip("/") else base_url
        return await self._list_dir(auth, dir_url)

    async def _list_dir(self, auth, dir_url, depth: int = 0):
        """列出目录内容。depth=0 时只列一层（不递归），提升性能"""
        try:
            items = await _webdav_list(dir_url, auth)
        except Exception as e:
            # 文件树浏览容忍单目录失败，静默返回空（错误已在 _webdav_list/上层记录）
            logger.error(f"WebDAV 列目录失败: {e}")
            return []
        from urllib.parse import urlparse
        cur = urlparse(dir_url).path.rstrip("/")

        result = []
        for item in items:
            name = item["name"]
            href = item["href"]
            if name.startswith("."): continue
            if unquote(href.rstrip("/")) == unquote(cur): continue

            raw = unquote(href).lstrip("/")
            bp = self._base_path + "/" if self._base_path else ""
            rel = raw.removeprefix(bp) if bp else raw

            if item.get("is_collection"):
                children = await self._list_dir(auth, f"{self._webdav_root}{href}", depth + 1) if depth < 2 else []
                result.append({"name": name, "path": rel, "type": "folder", "children": children})
            elif name.endswith((".md", ".canvas", ".txt", ".log", ".csv", ".json", ".yaml", ".yml", ".py", ".sh", ".conf", ".ppt", ".pptx", ".pdf")):
                result.append({"name": name, "path": rel, "type": "file"})

        # 排序：目录在前，文件在后
        result.sort(key=lambda x: (0 if x["type"] == "folder" else 1, x["name"].lower()))
        return result

    async def get_file_content(self, path: str) -> Optional[str]:
        """获取指定路径的文件内容（WebDAV 优先，本地回退）"""
        if self._is_webdav_configured():
            return await self._get_file_content_webdav(path)
        else:
            return self._local_get_file_content(path)

    async def _get_file_content_webdav(self, path: str) -> Optional[str]:
        """通过 WebDAV 获取文件内容。path 为 vault 内相对路径"""
        config = _get_settings()
        auth = _webdav_auth(config["webdav_user"], config["webdav_pass"])
        base_url = config["webdav_url"].rstrip("/")
        # path 去掉可能的 Obsidian Vault/ 前缀
        clean = unquote(path).lstrip("/")
        # 安全校验：禁止穿越到 vault 之外
        if any(part == ".." for part in clean.split("/")):
            logger.warning(f"拒绝越界 WebDAV 路径: {path}")
            return None
        bp = self._base_path + "/" if getattr(self, "_base_path", "") else ""
        clean = clean.removeprefix(bp) if bp else clean
        return await _webdav_get(_make_webdav_url(base_url, clean), auth)

    async def search_notes(self, query: str) -> list[dict]:
        """全文搜索笔记（WebDAV 优先，本地回退）"""
        if self._is_webdav_configured():
            return await self._search_notes_webdav(query)
        else:
            return self._local_search_notes(query)

    async def _search_notes_webdav(self, query: str) -> list[dict]:
        """通过 WebDAV 搜索笔记"""
        notes = await self._list_notes_webdav()
        results = []

        for note in notes[:20]:
            content = await self._get_note_content_webdav(note["filename"])
            if not content:
                continue

            if query.lower() in note.get("title", "").lower() or query.lower() in content.lower():
                snippet = self._extract_snippet(content, query)
                results.append({
                    "filename": note["filename"],
                    "path": note["filename"],
                    "title": note.get("title", note["filename"]),
                    "snippet": snippet,
                })

        return results

    def _extract_snippet(self, content: str, query: str, context_chars: int = 100) -> str:
        """提取包含查询词的文本片段"""
        lower_content = content.lower()
        lower_query = query.lower()
        idx = lower_content.find(lower_query)

        if idx == -1:
            return content[:200] + "..." if len(content) > 200 else content

        start = max(0, idx - context_chars)
        end = min(len(content), idx + len(query) + context_chars)

        snippet = ""
        if start > 0:
            snippet += "..."
        snippet += content[start:end]
        if end < len(content):
            snippet += "..."

        return snippet


# 全局实例
obsidian_service = ObsidianService()
