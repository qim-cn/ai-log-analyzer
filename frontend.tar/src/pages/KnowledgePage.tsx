/**
 * 知识库页面
 * 三栏布局：文件树 | 笔记内容 | 大纲
 * Tab: Obsidian | 已解决 | Linux
 */

import { useState, useEffect, useCallback } from 'react';
import {
  ArrowLeft, Search, FileText, Folder, FolderOpen, ChevronRight, ChevronDown,
  RefreshCw, Terminal, CheckCircle2, Trash2,
} from 'lucide-react';
import { obsidianService, type FileTreeNode, type ResolvedFile } from '@/services/obsidianService';
import { MarkdownRenderer } from '@/components/knowledge/MarkdownRenderer';
import { OutlinePanel } from '@/components/knowledge/OutlinePanel';
import { LinuxKnowledgePanel } from '@/components/knowledge/LinuxKnowledgePanel';
import { cn } from '@/utils';

interface KnowledgePageProps {
  onBack: () => void;
  initialPath?: string;
}

export function KnowledgePage({ onBack, initialPath }: KnowledgePageProps) {
  const [activeView, setActiveView] = useState<'obsidian' | 'resolved' | 'linux'>('resolved');
  const [tree, setTree] = useState<FileTreeNode[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPath, setSelectedPath] = useState<string | null>(initialPath || null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [loadingContent, setLoadingContent] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ path: string; title: string; snippet: string }[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // 已解决列表
  const [resolvedFiles, setResolvedFiles] = useState<ResolvedFile[]>([]);
  const [resolvedLoading, setResolvedLoading] = useState(false);

  const fetchTree = useCallback(async () => {
    setLoading(true);
    try {
      // 读配置：只加载设置中选中的浏览目录
      const cfg = await obsidianService.getBrowsePaths();
      const paths: string[] = cfg.browse_paths || [];
      if (paths.length > 0) {
        const trees = await Promise.all(paths.map(p => obsidianService.getFileTree(p)));
        const combined: FileTreeNode[] = [];
        trees.forEach((t, i) => {
          const dirName = paths[i] || '(根目录)';
          const items = (t.tree || []).filter((n: FileTreeNode) =>
            n.type === 'folder' || /\.(md|canvas|txt|ppt|pptx|pdf|json|log|csv|sh|py|yaml|yml|conf)$/i.test(n.name));
          if (items.length > 0) {
            combined.push({ name: dirName, path: paths[i], type: 'folder', children: items });
          }
        });
        setTree(combined);
      } else {
        // 没有选择 → 加载根目录
        const d = await obsidianService.getFileTree();
        setTree(d.tree || []);
      }
    } catch (err) { console.error('获取文件树失败:', err); }
    finally { setLoading(false); }
  }, []);

  const fetchResolved = useCallback(async () => {
    setResolvedLoading(true);
    try {
      const d = await obsidianService.listResolved();
      setResolvedFiles(d || []);
    } catch (err) { console.error(err); }
    finally { setResolvedLoading(false); }
  }, []);

  useEffect(() => { fetchTree(); fetchResolved(); }, [fetchTree, fetchResolved, activeView]);

  const fetchContent = useCallback(async (path: string) => {
    setLoadingContent(true);
    try {
      const d = await obsidianService.getFileContent(path);
      setFileContent(d.content || '');
    } catch (err) { setFileContent('加载失败'); }
    finally { setLoadingContent(false); }
  }, []);

  const fetchResolvedContent = useCallback(async (filename: string) => {
    setLoadingContent(true);
    try {
      const d = await obsidianService.getResolvedFile(filename);
      setFileContent(d.content || '空文件');
      setSelectedPath(filename);
    } catch (err) { setFileContent('加载失败'); }
    finally { setLoadingContent(false); }
  }, []);

  const handleFileClick = useCallback((path: string) => {
    setSelectedPath(path);
    fetchContent(path);
  }, [fetchContent]);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) { setSearchResults([]); return; }
    setIsSearching(true);
    try {
      const data = await obsidianService.search(searchQuery);
      setSearchResults(data.results);
    } catch (err) { console.error('搜索失败:', err); }
    finally { setIsSearching(false); }
  }, [searchQuery]);

  const handleOutlineClick = useCallback((lineNumber: number) => {
    const element = document.getElementById(`line-${lineNumber}`);
    element?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, []);

  const isAdmin = localStorage.getItem('user') ? (() => { try { return JSON.parse(localStorage.getItem('user') || '{}').role === 'admin'; } catch { return false; } })() : false;

  const handleDeleteResolved = async (filename: string) => {
    if (!confirm('确定删除这条已解决记录？')) return;
    try {
      await obsidianService.deleteResolvedFile(filename);
      fetchResolved();
      if (selectedPath === filename) { setSelectedPath(null); setFileContent(null); }
    } catch (err) { alert('删除失败'); }
  };

  const refreshAll = () => { fetchTree(); fetchResolved(); };

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="h-12 border-b border-border bg-card flex items-center px-4 gap-3">
        <button onClick={onBack} className="p-1.5 hover:bg-muted rounded-lg transition-colors">
          <ArrowLeft size={18} />
        </button>
        <div className="font-semibold text-sm">知识库</div>

        {/* View Tabs */}
        <div className="flex items-center gap-1 bg-muted rounded-lg p-0.5">
          <button onClick={() => setActiveView('resolved')} className={cn(
            'px-3 py-1 rounded-md text-xs transition-colors flex items-center gap-1',
            activeView === 'resolved' ? 'bg-background text-foreground shadow-sm font-medium' : 'text-muted-foreground hover:text-foreground'
          )}>
            <CheckCircle2 size={12} /> 已解决
          </button>
          <button onClick={() => setActiveView('obsidian')} className={cn(
            'px-3 py-1 rounded-md text-xs transition-colors',
            activeView === 'obsidian' ? 'bg-background text-foreground shadow-sm font-medium' : 'text-muted-foreground hover:text-foreground'
          )}>Obsidian</button>
          <button onClick={() => setActiveView('linux')} className={cn(
            'px-3 py-1 rounded-md text-xs transition-colors flex items-center gap-1',
            activeView === 'linux' ? 'bg-background text-foreground shadow-sm font-medium' : 'text-muted-foreground hover:text-foreground'
          )}><Terminal size={12} />Linux</button>
        </div>

        <div className="flex-1" />
        <button onClick={refreshAll} className="p-1.5 hover:bg-muted rounded-lg transition-colors" title="刷新">
          <RefreshCw size={15} />
        </button>
      </div>

      {/* Linux 面板全屏 */}
      {activeView === 'linux' && (
        <div className="flex-1 overflow-hidden">
          <LinuxKnowledgePanel />
        </div>
      )}

      {/* 已解决面板 */}
      {activeView === 'resolved' && (
        <div className="flex-1 flex overflow-hidden">
          <aside className="w-64 border-r border-border flex flex-col bg-card">
            <div className="p-2 border-b border-border text-xs font-medium text-muted-foreground flex items-center gap-1.5">
              <CheckCircle2 size={12} className="text-emerald-500" />
              已解决故障记录
              <span className="opacity-60">({resolvedFiles.length})</span>
            </div>
            <div className="flex-1 overflow-y-auto p-2">
              {resolvedLoading ? (
                <div className="text-center text-muted-foreground py-4 text-xs">加载中...</div>
              ) : resolvedFiles.length === 0 ? (
                <div className="text-center text-muted-foreground py-8 text-xs">暂无已解决记录</div>
              ) : (
                <div className="space-y-0.5">
                  {resolvedFiles.map((f) => (
                    <div key={f.filename} className="group flex items-center">
                      <button
                        onClick={() => fetchResolvedContent(f.filename)}
                        className={cn(
                          'flex-1 flex items-center gap-2 px-2 py-2 rounded-lg text-left transition-colors',
                          selectedPath === f.filename
                            ? 'bg-primary/10 text-primary border border-primary/20'
                            : 'hover:bg-muted'
                        )}
                      >
                        <FileText size={13} className={selectedPath === f.filename ? 'text-primary' : 'text-muted-foreground'} />
                        <div className="min-w-0 flex-1">
                          <div className="text-xs truncate">{f.title}</div>
                          {f.model && (
                            <span className="text-[9px] px-1 py-0.5 rounded bg-primary/10 text-primary mt-0.5 inline-block">
                              {f.model}
                            </span>
                          )}
                        </div>
                      </button>
                      {isAdmin && (
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDeleteResolved(f.filename); }}
                          className="p-1 hover:bg-red-500/10 rounded opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                          title="删除"
                        >
                          <Trash2 size={12} className="text-muted-foreground hover:text-destructive" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </aside>
          <main className="flex-1 overflow-y-auto">
            {loadingContent ? (
              <div className="flex items-center justify-center h-full text-muted-foreground text-sm">加载中...</div>
            ) : fileContent && selectedPath ? (
              <div className="max-w-[800px] mx-auto px-8 py-6">
                <MarkdownRenderer content={fileContent} onLinkClick={handleFileClick} />
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <div className="text-center">
                  <CheckCircle2 size={48} className="mx-auto mb-4 opacity-20 text-emerald-500" />
                  <div className="text-sm">选择左侧已解决记录查看详情</div>
                </div>
              </div>
            )}
          </main>
          {fileContent && selectedPath && (
            <aside className="w-56 border-l border-border bg-card overflow-y-auto">
              <OutlinePanel content={fileContent} onClick={handleOutlineClick} />
            </aside>
          )}
        </div>
      )}

      {/* Obsidian 面板 */}
      {activeView === 'obsidian' && (
      <div className="flex-1 flex overflow-hidden">
        <aside className="w-64 border-r border-border flex flex-col bg-card">
          <div className="p-2 border-b border-border">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text" value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="搜索笔记..."
                className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-input bg-background text-xs
                           focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            {isSearching ? (
              <div className="text-center text-muted-foreground py-4 text-xs">搜索中...</div>
            ) : searchResults.length > 0 ? (
              <div className="space-y-0.5">
                {searchResults.map((result) => (
                  <button
                    key={result.path}
                    onClick={() => { handleFileClick(result.path); setSearchResults([]); setSearchQuery(''); }}
                    className="w-full flex items-start gap-2 px-2 py-2 rounded-lg hover:bg-muted text-left"
                  >
                    <FileText size={14} className="text-muted-foreground shrink-0 mt-0.5" />
                    <div className="min-w-0">
                      <div className="text-xs font-medium truncate">{result.title}</div>
                      <div className="text-[10px] text-muted-foreground/60 truncate mt-0.5">{result.snippet}</div>
                    </div>
                  </button>
                ))}
              </div>
            ) : loading ? (
              <div className="text-center text-muted-foreground py-4 text-xs">加载中...</div>
            ) : (
              <FileTree nodes={tree} selectedPath={selectedPath} onFileClick={handleFileClick} />
            )}
          </div>
        </aside>
        <main className="flex-1 overflow-y-auto">
          {loadingContent ? (
            <div className="flex items-center justify-center h-full text-muted-foreground text-sm">加载中...</div>
          ) : fileContent ? (
            <div className="max-w-[800px] mx-auto px-8 py-6">
              <MarkdownRenderer content={fileContent} onLinkClick={handleFileClick} />
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <FileText size={48} className="mx-auto mb-4 opacity-20" />
                <div className="text-sm">选择左侧文件查看内容</div>
              </div>
            </div>
          )}
        </main>
        {fileContent && (
          <aside className="w-56 border-l border-border bg-card overflow-y-auto">
            <OutlinePanel content={fileContent} onClick={handleOutlineClick} />
          </aside>
        )}
      </div>
      )}
    </div>
  );
}

// ============================================================
// 文件树组件
// ============================================================

interface FileTreeProps {
  nodes: FileTreeNode[];
  selectedPath: string | null;
  onFileClick: (path: string) => void;
  level?: number;
}

function FileTree({ nodes, selectedPath, onFileClick, level = 0 }: FileTreeProps) {
  return (
    <div className="space-y-0.5">
      {nodes.map((node) => (
        <FileTreeNodeComponent
          key={node.path} node={node} selectedPath={selectedPath}
          onFileClick={onFileClick} level={level}
        />
      ))}
    </div>
  );
}

interface FileTreeNodeComponentProps {
  node: FileTreeNode;
  selectedPath: string | null;
  onFileClick: (path: string) => void;
  level: number;
}

function FileTreeNodeComponent({ node, selectedPath, onFileClick, level }: FileTreeNodeComponentProps) {
  const [expanded, setExpanded] = useState(level < 2);

  if (node.type === 'folder') {
    return (
      <div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-lg hover:bg-muted transition-colors text-left"
          style={{ paddingLeft: `${level * 12 + 8}px` }}
        >
          {expanded ? <ChevronDown size={12} className="text-muted-foreground" /> : <ChevronRight size={12} className="text-muted-foreground" />}
          {expanded ? <FolderOpen size={14} className="text-primary" /> : <Folder size={14} className="text-primary" />}
          <span className="text-xs font-medium truncate">{node.name}</span>
        </button>
        {expanded && node.children && (
          <FileTree nodes={node.children} selectedPath={selectedPath} onFileClick={onFileClick} level={level + 1} />
        )}
      </div>
    );
  }

  const isSelected = selectedPath === node.path;
  return (
    <button
      onClick={() => onFileClick(node.path)}
      className={cn(
        'w-full flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-colors text-left',
        isSelected ? 'bg-primary/10 text-primary border border-primary/20' : 'hover:bg-muted'
      )}
      style={{ paddingLeft: `${level * 12 + 24}px` }}
    >
      <FileText size={13} className={isSelected ? 'text-primary' : 'text-muted-foreground'} />
      <span className="text-xs truncate">{node.name}</span>
    </button>
  );
}
