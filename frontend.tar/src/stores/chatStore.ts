/**
 * 聊天状态管理
 */

import { create } from 'zustand';
import type { Message, CaseRef } from '@/types';
import { messageService, sendMessage, sessionService } from '@/services';
import { useSessionStore } from './sessionStore';

// 当前流式请求的 AbortController；切会话/重发时 abort 旧的，避免旧 chunk 写入造成串台
let streamController: AbortController | null = null;

interface ChatState {
  messages: Message[];
  loading: boolean;
  streaming: boolean;
  streamingContent: string;
  inputQuote: string;
  thinking: boolean;
  thinkingMessage: string;

  // Actions
  fetchMessages: (sessionId: string) => Promise<void>;
  sendMessage: (sessionId: string, content: string) => Promise<void>;
  regenerate: (sessionId: string) => Promise<void>;
  clearMessages: () => void;
  setInputQuote: (quote: string) => void;
  abortStreaming: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  loading: false,
  streaming: false,
  streamingContent: '',
  inputQuote: '',
  thinking: false,
  thinkingMessage: '',

  fetchMessages: async (sessionId) => {
    set({ loading: true });
    try {
      const data = await messageService.list(sessionId);
      set({ messages: data.messages });
    } finally {
      set({ loading: false });
    }
  },

  sendMessage: async (sessionId, content) => {
    const userMessage: Message = {
      id: `temp-${Date.now()}`,
      session_id: sessionId,
      role: 'user',
      content,
      created_at: new Date().toISOString(),
    };

    set((state) => ({
      messages: [...state.messages, userMessage],
      streaming: true,
      streamingContent: '',
      thinking: true,
      thinkingMessage: '正在分析...',
    }));

    // 取消上一次未完成的流式请求，避免切换会话/重发时旧 chunk 串台
    if (streamController) streamController.abort();
    streamController = new AbortController();
    const signal = streamController.signal;

    try {
      let fullContent = '';
      let hasStartedContent = false;
      let refs: CaseRef[] = [];

      for await (const chunk of sendMessage(sessionId, content, signal)) {
        if (chunk.error) throw new Error(chunk.error);

        if ((chunk as { refs?: CaseRef[] }).refs) {
          refs = (chunk as { refs?: CaseRef[] }).refs!;
          continue;
        }

        if (chunk.status === 'thinking') {
          set({ thinkingMessage: chunk.message || '正在思考...' });
          continue;
        }

        if (chunk.content && !hasStartedContent) {
          hasStartedContent = true;
          set({ thinking: false, thinkingMessage: '' });
        }

        if (chunk.content) {
          fullContent += chunk.content;
          set({ streamingContent: fullContent });
        }

        if (chunk.done) {
          // 回传会话标题，触发侧栏刷新
          if (chunk.session_title) {
            useSessionStore.getState().renameSession(sessionId, chunk.session_title);
          }
          break;
        }
      }

      const assistantMessage: Message = {
        id: `temp-${Date.now()}`,
        session_id: sessionId,
        role: 'assistant',
        content: fullContent,
        created_at: new Date().toISOString(),
        refs: refs.length ? refs : undefined,
      };

      set((state) => ({
        messages: [...state.messages, assistantMessage],
        streaming: false,
        streamingContent: '',
        thinking: false,
        thinkingMessage: '',
      }));

      // 首轮问答后自动生成会话标题（标题仍是默认值/"确认中 - "前缀时；失败静默）
      const sess = useSessionStore.getState().sessions.find((s) => s.id === sessionId);
      if (!sess || sess.title === '新对话' || sess.title.startsWith('确认中 - ')) {
        sessionService
          .autoTitle(sessionId)
          .then((r) => {
            if (r.updated) useSessionStore.getState().fetchSessions();
          })
          .catch(() => {
            /* AI 不可用时保持原标题，静默处理 */
          });
      }
    } catch (error) {
      // 主动取消（切会话/重发）不算错误，静默清理即可
      const aborted = (error as { name?: string })?.name === 'AbortError';
      set({ streaming: false, streamingContent: '', thinking: false, thinkingMessage: '' });
      if (aborted) return;
      throw error;
    }
  },

  regenerate: async (sessionId) => {
    const { messages } = get();
    // 找到最后一条用户消息
    const lastUserMsg = [...messages].reverse().find((m) => m.role === 'user');
    if (!lastUserMsg) return;

    // 删除最后一条 AI 回复
    const messagesWithoutLast = messages.filter(
      (m, i) => !(m.role === 'assistant' && i === messages.length - 1)
    );
    set({ messages: messagesWithoutLast });

    // 重新发送
    await get().sendMessage(sessionId, lastUserMsg.content);
  },

  clearMessages: () => {
    set({ messages: [], streamingContent: '', inputQuote: '', thinking: false, thinkingMessage: '' });
  },

  setInputQuote: (quote) => {
    set({ inputQuote: quote });
  },

  abortStreaming: () => {
    if (streamController) {
      streamController.abort();
      streamController = null;
    }
    set({ streaming: false, streamingContent: '', thinking: false, thinkingMessage: '' });
  },
}));
